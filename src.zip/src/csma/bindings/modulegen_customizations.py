
def post_register_types(root_module):
    root_module.add_include('"ns3/queue.h"')
    root_module.add_include('"ns3/error-model.h"')

